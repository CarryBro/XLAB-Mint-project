package com.example.new_kirill.fragments.lognRegister

import androidx.fragment.app.Fragment
import com.example.xlab.R

class RegisterFragment: Fragment(R.layout.fragment_register)  {
}