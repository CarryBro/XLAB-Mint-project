package com.example.new_kirill.fragments.lognRegister

import androidx.fragment.app.Fragment
import com.example.xlab.R

class IntroductionFragment: Fragment(R.layout.fragment_introduction)  {
}