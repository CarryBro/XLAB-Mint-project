package com.example.xlab

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class XlabApplication: Application() {
}