package com.example.new_kirill.fragments.lognRegister

import androidx.fragment.app.Fragment
import com.example.xlab.R

class AccountOptionsFragment: Fragment(R.layout.fragment_account_options)  {
}